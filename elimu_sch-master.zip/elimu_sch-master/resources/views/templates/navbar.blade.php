<nav class="nav-bar w-100 p-0 m-0">
    <div class="logo-container">
        <img src="images/ES_LOGO.png" class="logo-img" alt="">
    </div>
    <div class="menu-button w-25 pe-2">

        <h4 class="name">{{$LoggedUserInfo['staff_name']}}</h4>
    </div>
</nav>