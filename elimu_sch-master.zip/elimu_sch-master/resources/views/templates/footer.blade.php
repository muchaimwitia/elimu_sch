<footer class="footer-section w-100">
    <div class="upper-foot w-100">
        <a href="">CALENDERS</a>
        <a href="">CONTACT</a>
        <a href="">PRIVACY POLICIES</a>
    </div>
    <div class="lower-foot w-100">
        <div class="logo-display">
            <span class="line"></span>
            <img src="images/ES_white.png" alt="">
            <span class="line"></span>
        </div>
        <h3>SUGOI, BONDO WEST DISTRICT, MAZRAWI/P.O. BOX 5100-0011</h3>
        <div class="socials-container">
            <div class="round">
                <i class="fa-brands fa-facebook-f"></i>
            </div>
            <div class="round">
                <i class="fa-brands fa-twitter"></i>
            </div>
            <div class="round">
                <i class="fa-brands fa-instagram"></i>
            </div>
            <div class="round">
                <i class="fa-brands fa-linkedin-in"></i>
            </div>
        </div>
    </div>
</footer>